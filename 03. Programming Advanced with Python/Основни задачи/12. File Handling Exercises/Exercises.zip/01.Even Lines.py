replaceable_items = {"-", ",", ".", "!", "?"}
with open('text.txt') as file:
	my_list = file.readlines()
	for index in range(len(my_list)):
		if index % 2 == 0:
			result = ''.join(['@' if c in replaceable_items else c for c in my_list[index]])
			print(' '.join(list(reversed(result.strip().split()))))
