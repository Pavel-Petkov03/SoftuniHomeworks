import re
def get_info(repo):
	with open(repo) as file:
		return re.findall(r'[a-z\']+',''.join(file.readlines()).lower())

final_dict ={}
validated_words_file = get_info('words.txt')
validated_input_file = get_info('input.txt')
for word in validated_words_file:
	final_dict[word] = validated_input_file.count(word)

result = {word: times for word, times in sorted(final_dict.items(), key=lambda x: -x[1])}
with open('output.txt','w') as file:
	file.write('\n'.join([f'{c[0]} - {c[1]}' for c in result.items()]))

