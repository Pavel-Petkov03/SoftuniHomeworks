import re
result = 0
try:
	with open('numbers.txt') as file:
		b = re.findall('\d+', ''.join(file.readlines()))
		print(sum(map(int, b)))

except FileNotFoundError:
	print(1)