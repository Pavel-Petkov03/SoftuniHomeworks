from person.project import Animal


class Cat(Animal):
    @staticmethod
    def meow():
        return "meowing..."