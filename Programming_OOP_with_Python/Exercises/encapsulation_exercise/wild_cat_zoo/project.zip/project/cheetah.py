from project.animal import Animal


class Cheetah(Animal):
    def get_needs(self):
        return 60


