from project.animal import Animal


class Tiger(Animal):
    def get_needs(self):
        return 45

