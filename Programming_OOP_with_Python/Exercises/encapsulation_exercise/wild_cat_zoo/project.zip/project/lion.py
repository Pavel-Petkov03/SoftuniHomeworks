from project.animal import Animal


class Lion(Animal):
    def get_needs(self):
        return 50
