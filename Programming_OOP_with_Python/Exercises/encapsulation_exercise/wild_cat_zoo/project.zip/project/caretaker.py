from project.worker import Worker


class Caretaker(Worker):
    pass
