from hero.project.hero import Hero

import unittest


class TestHero(unittest.TestCase):

    def test__init__data(self):
        my_init_obj = Hero('name', 1, 20, 40)
        name = 'name'
        level = 1
        health = 20.0
        damage = 40.0
        self.assertEqual(name, my_init_obj.username)
        self.assertEqual(level, my_init_obj.level)
        self.assertEqual(health, my_init_obj.health)
        self.assertEqual(damage, my_init_obj.damage)

    def test_battle_taken_object_username_equals_instance_username__expected_exception(self):
        error_init_obj = Hero('name', 1, 1.0, 1.0)
        same_name_obj = Hero('name', 10, 20.0, 30.0)
        with self.assertRaises(Exception) as ex:
            error_init_obj.battle(same_name_obj)
        self.assertEqual("You cannot fight yourself", str(ex.exception))

    def test_battle_instance_health_less_or_equal_to_zero_expected_value_error(self):
        my_less_health_obj = Hero('name', 1, -1.0, 20.0)
        my_ok_another_object = Hero('another_name', 1, 1.0, 1.0)
        with self.assertRaises(ValueError)as ex:
            my_less_health_obj.battle(my_ok_another_object)
        self.assertEqual('Your health is lower than or equal to 0. You need to rest', str(ex.exception))

    def test_battle_object_health_less_than_zero_expected_value_error(self):
        my_less_health_obj = Hero('name', 1, -1.0, 20.0)
        my_ok_another_object = Hero('another_name', 1, 1.0, 1.0)
        with self.assertRaises(ValueError)as ex:
            my_ok_another_object.battle(my_less_health_obj)
        self.assertEqual(f"You cannot fight {my_less_health_obj.username}. He needs to rest", str(ex.exception))

    def test_both_players_under_zero_health_expected_draw(self):
        one_equal_obj = Hero('username', 10, 5.0, 1.0)
        another_equal_obj = Hero('another_username', 1, 5.0, 10.0)
        actual_result_for_variation = one_equal_obj.battle(another_equal_obj)
        self.assertEqual(actual_result_for_variation, 'Draw')
        # test for both to be equal to zero
        one_equal_obj = Hero('username', 5, 5.0, 2.0)
        another_equal_obj = Hero('another_username', 1, 10.0, 5.0)
        actual_name_for_tho_zeros = one_equal_obj.battle(another_equal_obj)
        self.assertEqual(one_equal_obj.health, 0)
        self.assertEqual(another_equal_obj.health, 0)
        self.assertEqual(actual_name_for_tho_zeros, 'Draw')
        self.assertEqual(one_equal_obj.level, 5)
        self.assertEqual(another_equal_obj.level, 1)


    def test_object_hero_lost_expected_you_win(self):
        better_instance_object = Hero('testov', 15, 1000.0, 12.0)
        weaker_new_obj = Hero('another_testov', 15, 20.0, 12.0)
        expected_new_health = 825.0
        expected_new_damage = 17.0
        expected_new_level = 16
        actual = better_instance_object.battle(weaker_new_obj)
        self.assertEqual(actual, 'You win')
        self.assertEqual(expected_new_health, better_instance_object.health)
        self.assertEqual(expected_new_damage, better_instance_object.damage)
        self.assertEqual(expected_new_level, better_instance_object.level)

    def test_instance_hero_lost_expected_you_loose(self):
        weaker_instance_object = Hero('testov', 15, 20, 12)
        better_method_object = Hero('another_testov', 15, 1000, 12)
        actual = weaker_instance_object.battle(better_method_object)
        expected_new_health = 825.0
        expected_new_damage = 17.0
        expected_new_level = 16
        self.assertEqual(actual, 'You lose')
        self.assertEqual(expected_new_health, better_method_object.health)
        self.assertEqual(expected_new_damage, better_method_object.damage)
        self.assertEqual(expected_new_level, better_method_object.level)

    def test_str_method(self):
        my_less_health_obj = Hero('name', 1, 1.0, 20.0)
        expected = f"Hero {my_less_health_obj.username}: {my_less_health_obj.level} lvl\n" \
                   f"Health: {my_less_health_obj.health}\n" \
                   f"Damage: {my_less_health_obj.damage}\n"
        massive = my_less_health_obj.__str__().split('\n')
        self.assertEqual(massive[0], f'Hero {my_less_health_obj.username}: {my_less_health_obj.level} lvl')
        self.assertEqual(massive[1], f"Health: {my_less_health_obj.health}")
        self.assertEqual(massive[2], f"Damage: {my_less_health_obj.damage}")

"""
class Hero:
    username: str
    health: float
    damage: float
    level: int

    def __init__(self, username: str, level: int, health: float, damage: float):
        self.username = username
        self.level = level
        self.health = health
        self.damage = damage

    def battle(self, enemy_hero):
        if enemy_hero.username == self.username:
            raise Exception("You cannot fight yourself")

        if self.health <= 0:
            raise ValueError("Your health is lower than or equal to 0. You need to rest")

        if enemy_hero.health <= 0:
            raise ValueError(f"You cannot fight {enemy_hero.username}. He needs to rest")

        player_damage = self.damage * self.level
        enemy_hero_damage = enemy_hero.damage * enemy_hero.level

        self.health -= enemy_hero_damage
        enemy_hero.health -= player_damage

        if self.health <= 0 and enemy_hero.health <= 0:
            return "Draw"

        if enemy_hero.health <= 0:
            self.level += 1
            self.health += 5
            self.damage += 5
            return "You win"

        enemy_hero.level += 1
        enemy_hero.health += 5
        enemy_hero.damage += 5
        return "You lose"

    def __str__(self):
        return f"Hero {self.username}: {self.level} lvl\n" \
               f"Health: {self.health}\n" \
               f"Damage: {self.damage}\n"

"""
